package com.example.feemeowapp.ui.response

import com.google.gson.annotations.SerializedName

data class GetCommentResultItem(

	@field:SerializedName("image")
	val image: String? = null,

	@field:SerializedName("idBreed")
	val idBreed: Int? = null,

	@field:SerializedName("name")
	val name: String? = null,

	@field:SerializedName("description")
	val description: String? = null
)

data class RasSearchResponse(

	@field:SerializedName("getCommentResult")
	val getCommentResult: List<GetCommentResultItem?>? = null,

	@field:SerializedName("error")
	val error: Boolean? = null,

	@field:SerializedName("message")
	val message: String? = null
)
