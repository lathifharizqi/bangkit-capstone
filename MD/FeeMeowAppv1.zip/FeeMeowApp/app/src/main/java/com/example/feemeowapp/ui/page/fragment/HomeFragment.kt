package com.example.feemeowapp.ui.page.fragment

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import androidx.fragment.app.Fragment
import android.view.View
import android.view.ViewGroup
import com.example.feemeowapp.R
import com.example.feemeowapp.databinding.FragmentHomeBinding
import com.example.feemeowapp.ui.page.search.SearchBreedsActivity

class HomeFragment : Fragment(R.layout.fragment_home) {

    private var _binding: FragmentHomeBinding? = null

    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        val view = binding.root
        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        action()
    }
    private fun action(){
        binding.btnSearch.setOnClickListener{
            val i = Intent(requireActivity(), SearchBreedsActivity::class.java)
            startActivity(i)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}


//        //Recyler View
//        vpSlider = view.findViewById(R.id.vp_sliderHome)
//        rvBreeds = view.findViewById(R.id.rv_breeds)
//        rvBreeds2 = view.findViewById(R.id.rv_breeds2)
//
//        var arrSlider = ArrayList<Int>()
//        arrSlider.add(R.drawable.gambar_vlog)
//        arrSlider.add(R.drawable.img_forum)
//        arrSlider.add(R.drawable.img_access)
//        arrSlider.add(R.drawable.img_kualitas)
//        arrSlider.add(R.drawable.image_signup)
//
//        val adapterSlider = AdapterSlider(arrSlider, activity)
//        vpSlider.adapter = adapterSlider
//
//        val layoutManager = LinearLayoutManager(activity)
//        layoutManager.orientation = LinearLayoutManager.HORIZONTAL
//
//        rvBreeds.adapter = BreedsCatAdapter(arrBreedsCat)
//        rvBreeds.layoutManager = layoutManager
//
//        val layoutManager2 = LinearLayoutManager(activity)
//        layoutManager.orientation = LinearLayoutManager.HORIZONTAL
//
//        rvBreeds2.adapter = BreedsCatAdapter2(arrBreedsCat2)
//        rvBreeds2.layoutManager = layoutManager2
//
//
//    }

//    //BreadCat pertama
//    val arrBreedsCat: ArrayList<BreedsCat>get(){
//        val arr = ArrayList<BreedsCat>()
//        val p1 = BreedsCat()
//        p1.nama = "Meong 1"
//        p1.deskripsi =  "kucing lucu"
//        p1.gambar = R.drawable.gambar_vlog
//
//        val p2 = BreedsCat()
//        p2.nama = "Meong 2"
//        p2.deskripsi =  "asal kota bandung"
//        p2.gambar = R.drawable.gambar_vlog
//
//        val p3 = BreedsCat()
//        p3.nama = "Meong 3"
//        p3.deskripsi =  "asal kota lampung"
//        p3.gambar = R.drawable.gambar_vlog
//
//        val p4 = BreedsCat()
//        p4.nama = "Meong 4"
//        p4.deskripsi =  "asal kota palembang"
//        p4.gambar = R.drawable.gambar_vlog
//
//        arr.add(p1)
//        arr.add(p2)
//        arr.add(p3)
//        arr.add(p4)
//
//        return arr
//    }
//    //BreadCat kedua
//    val arrBreedsCat2: ArrayList<BreedsCat>get(){
//        val arr = ArrayList<BreedsCat>()
//        val p1 = BreedsCat()
//        p1.nama = "Meong 1"
//        p1.deskripsi =  "kucing lucu"
//        p1.gambar = R.drawable.gambar_vlog
//
//        val p2 = BreedsCat()
//        p2.nama = "Meong 2"
//        p2.deskripsi =  "asal kota bandung"
//        p2.gambar = R.drawable.gambar_vlog
//
//        val p3 = BreedsCat()
//        p3.nama = "Meong 3"
//        p3.deskripsi =  "asal kota lampung"
//        p3.gambar = R.drawable.gambar_vlog
//
//        val p4 = BreedsCat()
//        p4.nama = "Meong 4"
//        p4.deskripsi =  "asal kota palembang"
//        p4.gambar = R.drawable.gambar_vlog
//
//        arr.add(p1)
//        arr.add(p2)
//        arr.add(p3)
//        arr.add(p4)
//
//        return arr
//    }
