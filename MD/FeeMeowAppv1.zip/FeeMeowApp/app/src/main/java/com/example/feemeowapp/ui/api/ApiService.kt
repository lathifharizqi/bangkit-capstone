package com.example.feemeowapp.ui.api

import com.example.feemeowapp.ui.request.RegisterRequest
import com.example.feemeowapp.ui.request.SignInRequest
import com.example.feemeowapp.ui.response.LoginResponse
import com.example.feemeowapp.ui.response.RasDetailResponse
import com.example.feemeowapp.ui.response.RasSearchResponse
import com.example.feemeowapp.ui.response.RegisterResponse
import retrofit2.Call
import retrofit2.http.*

interface ApiService {

    @GET("display")
    fun getSearch(
        @Query("q") name: String
    ): Call<RasSearchResponse>

    @GET("display/{name}")
    fun getUserDetail(
        @Path("username") name: String
    ): Call<RasDetailResponse>

    //Post Login
    @POST("login")
    fun loginUser(
       @Body request: SignInRequest
    ): retrofit2.Call<LoginResponse>

    //Post Regis
    @POST("register")
    fun registerUser(
        @Body request: RegisterRequest
    ): retrofit2.Call<RegisterResponse>
}