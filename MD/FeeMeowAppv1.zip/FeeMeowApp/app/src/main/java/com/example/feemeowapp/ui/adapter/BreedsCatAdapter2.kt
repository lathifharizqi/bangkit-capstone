package com.example.feemeowapp.ui.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.feemeowapp.R
import com.example.feemeowapp.ui.model.BreedsCat

class BreedsCatAdapter2(var data:ArrayList<BreedsCat>):RecyclerView.Adapter<BreedsCatAdapter2.Holder>() {

    class Holder(view: View): RecyclerView.ViewHolder(view){

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder {
        val view: View = LayoutInflater.from(parent.context).inflate(R.layout.item_breed2, parent, false)
        return Holder(view)
    }

    override fun getItemCount(): Int {
        return data.size
    }

    override fun onBindViewHolder(holder: Holder, position: Int) {

    }

}