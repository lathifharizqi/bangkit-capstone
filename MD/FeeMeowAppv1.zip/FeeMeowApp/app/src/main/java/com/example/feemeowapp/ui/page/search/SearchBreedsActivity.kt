package com.example.feemeowapp.ui.page.search

import android.app.SearchManager
import android.content.ContentValues.TAG
import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.appcompat.widget.SearchView
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.feemeowapp.databinding.ActivitySearchBreedsBinding
import com.example.feemeowapp.ui.adapter.BreedsCatAdapter
import com.example.feemeowapp.ui.api.ApiConfig
import com.example.feemeowapp.ui.model.BreedsCat
import com.example.feemeowapp.ui.response.GetCommentResultItem
import com.example.feemeowapp.ui.response.RasSearchResponse
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class SearchBreedsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySearchBreedsBinding
    private var listBreeds = ArrayList<BreedsCat>()
    private lateinit var breedsCatAdapter: BreedsCatAdapter


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySearchBreedsBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)

        val layoutManager = LinearLayoutManager(this)
        binding.tvUser.layoutManager = layoutManager
        val itemDecoration = DividerItemDecoration(this, layoutManager.orientation)
        binding.tvUser.addItemDecoration(itemDecoration)

        val searchManager = getSystemService(Context.SEARCH_SERVICE) as SearchManager

        binding.tvSearch.setSearchableInfo(searchManager.getSearchableInfo(componentName))
        binding.tvSearch.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String): Boolean {
                return if(query.isEmpty())
                    true
                else {
                    val size = listBreeds.size
                    listBreeds.clear()
                    binding.tvUser.adapter?.notifyItemRangeRemoved(0, size)

                    findBreeds(query)
                    true
                }
            }
            override fun onQueryTextChange(newText: String): Boolean {
                return false
            }
        })
    }

    private fun findBreeds(name: String) {
        showLoading(true)
        val client = ApiConfig.getApiService().getSearch(name)
        client.enqueue(object : Callback<RasSearchResponse> {

            override fun onResponse(
                call: Call<RasSearchResponse>,
                response: Response<RasSearchResponse>

            ) {
                showLoading(false)
                if (response.isSuccessful) {
                    val responseBody = response.body()
                    if (responseBody != null) {
                        responseBody.getCommentResult.let{ setUserData(it as ArrayList<GetCommentResultItem>) }
                    }
                } else {
                    Log.e(TAG, "onFailure: ${response.message()}")
                }
            }
            override fun onFailure(call: Call<RasSearchResponse>, t: Throwable) {
                showLoading(false)
                Log.e(TAG, "onFailure: ${t.message}")
            }
        })
    }

    private fun setUserData(it: ArrayList<GetCommentResultItem>) {
        for (Ras in it) {
            val newUser = BreedsCat(Ras.name, Ras.image)
            listBreeds.add(newUser)
        }
        breedsCatAdapter = BreedsCatAdapter(listBreeds)
        binding.tvUser.adapter = breedsCatAdapter
        binding.tvUser.layoutManager = LinearLayoutManager(this)
        breedsCatAdapter.setOnItemClickCallback(object : BreedsCatAdapter.OnItemClickCallback {
            override fun onItemClicked(data: BreedsCat) {
                moveDetail(data)
            }
        })
    }

    private fun moveDetail(data: BreedsCat) {
        val username = ambilName(data)
        val intent = Intent(this@SearchBreedsActivity, DetailSearchActivity::class.java)
        intent.putExtra(DetailSearchActivity.username1, username)
        startActivity(intent)
    }

    private fun ambilName(data: BreedsCat): BreedsCat?  {
        var ambil: BreedsCat? = null

        for(ras in listBreeds) {
            if(ras.nama == data.nama)
                ambil = ras
        }
        return ambil
    }

    private fun showLoading(isLoading: Boolean) {
        if (isLoading) {
            binding.ProgresBar.visibility = View.VISIBLE
        } else {
            binding.ProgresBar.visibility = View.GONE
        }
    }


}