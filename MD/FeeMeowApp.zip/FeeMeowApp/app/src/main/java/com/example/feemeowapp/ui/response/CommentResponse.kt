package com.example.feemeowapp.ui.model

import com.google.gson.annotations.SerializedName

data class CommentResponse(

    @field:SerializedName("getCommentResult")
    val getCommentResult: ArrayList<GetCommentResultItem>,

    @field:SerializedName("error")
    val error: Boolean? = null,

    @field:SerializedName("message")
    val message: String? = null
) {

    data class GetCommentResultItem(

        @field:SerializedName("dateCreated")
        val dateCreated: String? = null,

        @field:SerializedName("createdBy")
        val createdBy: String? = null,

        @field:SerializedName("nama_lengkap")
        val namaLengkap: String? = null,

        @field:SerializedName("body")
        val body: String? = null,

        @field:SerializedName("idPost")
        val idPost: Int? = null
    )
}