package com.example.feemeowapp.ui.page.search

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import com.bumptech.glide.Glide
import com.example.feemeowapp.databinding.ActivityDetailSearchBinding
import com.example.feemeowapp.ui.api.ApiService
import com.example.feemeowapp.ui.api.apiConfig
import com.example.feemeowapp.ui.model.BreedsCat
import com.example.feemeowapp.ui.response.RasDetailResponse
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class DetailSearchActivity : AppCompatActivity() {
    companion object {
        private val TAG = "DetailUser"
        var userDetail = ""
        const val username1 = "username"
    }

    private lateinit var binding: ActivityDetailSearchBinding
    private lateinit var detailRas: RasDetailResponse

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailSearchBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setTitle("Halaman Ras Detail")

        supportActionBar?.elevation = 0f

        val fromMain = intent.getParcelableExtra<BreedsCat>(username1) as BreedsCat
        userDetail = fromMain.nama.toString()

        fromMain.nama?.let { findUser(it) }
    }

    private fun findUser(name: String) {
        showLoading(true)
        val client = apiConfig.apiService.getUserDetail(name)
        client.enqueue(object : Callback<RasDetailResponse> {
            override fun onResponse(
                call: Call<RasDetailResponse>,
                response: Response<RasDetailResponse>
            ) {
                showLoading(false)
                if (response.isSuccessful) {
                    val responseBody = response.body()
                    if (responseBody != null) {
                        detailRas = responseBody
                        Glide.with(this@DetailSearchActivity)
                            .load(detailRas.image)
                            .circleCrop()
                            .into(binding.imgGambarDetail)
                        binding.apply {
                            txtNamaDetail.text = detailRas.name
                            txtDeskDetail.text = detailRas.description
                        }
                    }
                } else {
                    Log.e(TAG, "onFailure: ${response.message()}")
                }
            }
            override fun onFailure(call: Call<RasDetailResponse>, t: Throwable) {
                showLoading(false)
                Log.e(TAG, "onFailure: ${t.message}")
            }
        })
    }

    private fun showLoading(isLoading: Boolean) {
        if (isLoading) {
            binding.ProgresBar.visibility = View.VISIBLE
        } else {
            binding.ProgresBar.visibility = View.GONE
        }
    }
}