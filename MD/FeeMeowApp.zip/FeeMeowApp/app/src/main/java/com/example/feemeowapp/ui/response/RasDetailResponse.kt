package com.example.feemeowapp.ui.response

import com.google.gson.annotations.SerializedName

data class RasDetailResponse(

	@field:SerializedName("image")
	val image: String? = null,

	@field:SerializedName("idBreed")
	val idBreed: Int? = null,

	@field:SerializedName("name")
	val name: String? = null,

	@field:SerializedName("description")
	val description: String? = null
)

//data class RasDetailResponse(
//
//	@field:SerializedName("getDetailRas")
//	val getDetailRas: List<GetDetailRas?>? = null,
//
//	@field:SerializedName("error")
//	val error: Boolean? = null,
//
//	@field:SerializedName("message")
//	val message: String? = null
//)
