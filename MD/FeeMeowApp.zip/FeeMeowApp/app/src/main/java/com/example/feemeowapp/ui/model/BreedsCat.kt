package com.example.feemeowapp.ui.model

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class BreedsCat (
          var nama: String? = null,
          var deskripsi: String? = null,
          var gambar: String? = null
): Parcelable


