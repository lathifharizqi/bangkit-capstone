package com.example.feemeowapp.ui.detilforum

import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.bumptech.glide.Glide
import com.example.feemeowapp.databinding.ActivityDetailForumBinding
import com.example.feemeowapp.ui.adapter.CommentAdapter
import com.example.feemeowapp.ui.api.apiConfig
import com.example.feemeowapp.ui.model.CommentResponse
import com.example.feemeowapp.ui.response.FileUploadResponse
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class DetailForumActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDetailForumBinding
    private lateinit var adapter: CommentAdapter


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailForumBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.hide()

        binding.tvTitleDesc.text = intent.getStringExtra("intent_title")
        binding.tvFullname.text = intent.getStringExtra("intent_fullname")
        binding.tvDate.text = intent.getStringExtra("intent_date")
        binding.tvDescriptionDetail.text = intent.getStringExtra("intent_description")

        Glide.with(this)
            .load(intent.getStringExtra("intent_image"))
            .into(binding.ivImageDetail)

        adapter = CommentAdapter(arrayListOf(), this@DetailForumActivity)
        binding.rvComment.layoutManager = LinearLayoutManager(this)
        binding.rvComment.setHasFixedSize(true)
        binding.rvComment.adapter = adapter
        getStudents()
        binding.btnSubmit.setOnClickListener {
            uploadComment()
        }
    }

    private fun uploadComment() {
        val intentId = intent.getIntExtra(EXTRA_ID, 3)
        val title = intentId .toString().toRequestBody("text/plain".toMediaType())
        val body =
            binding.edReview.text.toString().toRequestBody("text/plain".toMediaType())
        val createdBy = "danala04".toRequestBody("text/plain".toMediaType())
        val dateCreated = "22-02-02".toRequestBody("text/plain".toMediaType())


        val service =
            apiConfig.apiService.uploadComment(title, body, createdBy, dateCreated)

        service.enqueue(object : Callback<FileUploadResponse> {
            override fun onResponse(
                call: Call<FileUploadResponse>,
                response: Response<FileUploadResponse>
            ) {
                if (response.isSuccessful) {
                    val responseBody = response.body()
                    if (responseBody != null && !responseBody.error) {
                        Toast.makeText(
                            this@DetailForumActivity,
                            responseBody.message,
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                } else {
                    Toast.makeText(
                        this@DetailForumActivity,
                        response.message(),
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }

            override fun onFailure(call: Call<FileUploadResponse>, t: Throwable) {
                Toast.makeText(
                    this@DetailForumActivity,
                    "Gagal memposting ke forum",
                    Toast.LENGTH_SHORT
                ).show()
            }
        })
    }



    fun setData(data: ArrayList<CommentResponse.GetCommentResultItem>) {
        adapter.setData(data)
    }

    fun getStudents() {
        val intentId = intent.getIntExtra(EXTRA_ID, 3)
        apiConfig.apiService.getComment(intentId).enqueue(object : Callback<CommentResponse> {
            override fun onResponse(
                call: Call<CommentResponse>,
                response: Response<CommentResponse>
            ) {
                if (response.isSuccessful) {
                    val data = response.body()
                    if (data != null) {
                        setData(data.getCommentResult)
                    }
                }
            }

            override fun onFailure(call: Call<CommentResponse>, t: Throwable) {
                Log.d("Error Get", "" + t.stackTraceToString())
            }
        })
    }

    companion object {
        const val EXTRA_ID = "extra_id"
    }
}

