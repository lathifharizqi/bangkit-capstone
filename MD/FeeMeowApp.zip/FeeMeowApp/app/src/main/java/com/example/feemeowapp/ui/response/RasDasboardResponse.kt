package com.example.feemeowapp.ui.response

import com.google.gson.annotations.SerializedName

data class RasDasboardResponse(

	@field:SerializedName("error")
	val error: Boolean? = null,

	@field:SerializedName("message")
	val message: String? = null,

	@field:SerializedName("getSearchResult")
	val getSearchResult: ArrayList<GetSearchResultItem>
) {
	data class	GetSearchResultItem(
		@field:SerializedName("name")
		val name: String? = null,

		@field:SerializedName("description")
		val description: String? = null,

		@field:SerializedName("image")
		val image: String? = null,

		@field:SerializedName("idBreed")
		val idBreed: Int? = null


	)
}

