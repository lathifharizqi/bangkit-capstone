package com.example.feemeowapp.ui.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.feemeowapp.databinding.ItemCommentBinding
import com.example.feemeowapp.ui.model.CommentResponse



class CommentAdapter(
    private val listComment: ArrayList<CommentResponse.GetCommentResultItem>,
    val ctx: Context
) :
    RecyclerView.Adapter<CommentAdapter.CommentViewHolder>() {

    inner class CommentViewHolder(val binding: ItemCommentBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(user: CommentResponse.GetCommentResultItem) {
            binding.apply {
                tvNamaLengkapComment.text = user.namaLengkap
                tvDateComment.text = user.dateCreated
                tvIsiComment.text = user.body
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CommentViewHolder {
        val view =
            ItemCommentBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return CommentViewHolder(view)
    }

    override fun onBindViewHolder(holder: CommentViewHolder, position: Int) {
        holder.bind(listComment[position])
    }

    override fun getItemCount(): Int = listComment.size

    fun setData(data: ArrayList<CommentResponse.GetCommentResultItem>) {
        listComment.clear()
        listComment.addAll(data)
        notifyDataSetChanged()
    }
}
