package com.example.feemeowapp.ui.page.fragment

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.*
import android.widget.Toast
import androidx.core.content.PermissionChecker.checkSelfPermission
import androidx.fragment.app.Fragment
import com.example.feemeowapp.databinding.FragmentScanBinding
import com.example.feemeowapp.ui.page.scan.ScanCameraActivity

private var _binding: FragmentScanBinding? = null
private val binding get() = _binding!!

class ScanFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentScanBinding.inflate(inflater, container, false)
        val view = binding.root
        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupAction()
    }

    private fun setupAction() {
        binding.btnNext.setOnClickListener() {
                val i = Intent(requireActivity(), ScanCameraActivity::class.java)
                startActivity(i)
//                AlertDialog.Builder(requireActivity()).apply {
//                setTitle("Yeah!")
//                setMessage("Chosse Camera or Upload Image From Galery")
//                setPositiveButton("Next") { _, _ ->
//                    val intent = Intent(requireActivity(), ScanCameraActivity::class.java)
//                    intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK
//                    startActivity(intent)
////                    finish()
//                }
//                create()
//                show()
//            }
        }
    }
}