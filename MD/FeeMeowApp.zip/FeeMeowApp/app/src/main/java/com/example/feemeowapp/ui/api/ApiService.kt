package com.example.feemeowapp.ui.api

import com.example.feemeowapp.ui.request.RegisterRequest
import com.example.feemeowapp.ui.request.SignInRequest
import com.example.feemeowapp.ui.response.*
import retrofit2.Call
import retrofit2.http.*

interface ApiService {

    @GET("search")
    fun getSearch(
        @Query("name") name: String
    ): Call<RasSearchResponse>

    @GET("display/{name}")
    fun getUserDetail(
        @Path("name") name: String
    ): Call<RasDetailResponse>

    @GET("ras")
    fun getRas(): Call<RasDasboardResponse>


    //Post Login
    @POST("login")
    fun loginUser(
       @Body request: SignInRequest
    ): retrofit2.Call<LoginResponse>

    //Post Regis
    @POST("register")
    fun registerUser(
        @Body request: RegisterRequest
    ): retrofit2.Call<RegisterResponse>
}