package com.example.feemeowapp.ui.api

import com.example.feemeowapp.ui.forum.ResponseModel
import com.example.feemeowapp.ui.model.CommentResponse
import com.example.feemeowapp.ui.request.RegisterRequest
import com.example.feemeowapp.ui.request.SignInRequest
import com.example.feemeowapp.ui.response.*
import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.Call
import retrofit2.http.*

interface ApiService {

    @GET("search")
    fun getSearch(
        @Query("name") name: String
    ): Call<RasSearchResponse>

    @GET("display/{name}")
    fun getUserDetail(
        @Path("name") name: String
    ): Call<RasDetailResponse>

    @GET("ras")
    fun getRas(): Call<RasDasboardResponse>

    //Post Login
    @POST("login")
    fun loginUser(
       @Body request: SignInRequest
    ): retrofit2.Call<LoginResponse>

    //Post Regis
    @POST("register")
    fun registerUser(
        @Body request: RegisterRequest
    ): retrofit2.Call<RegisterResponse>

    //Get Forum
    @GET("forum")
    fun getForum(): Call<ResponseModel>

    //Post Forum with image
    @Multipart
    @POST("forum")
    fun uploadForum(
        @Part file: MultipartBody.Part,
        @Part("title") title: RequestBody,
        @Part("body") body: RequestBody,
        @Part("createdBy") createdBy: RequestBody,
        @Part("dateCreated") dateCreated: RequestBody
    ): Call<FileUploadResponse>

    //Post Forum without image
    @Multipart
    @POST("forum")
    fun uploadText(
        @Part("title") title: RequestBody,
        @Part("body") body: RequestBody,
        @Part("createdBy") createdBy: RequestBody,
        @Part("dateCreated") dateCreated: RequestBody
    ): Call<FileUploadResponse>

    //GetComment
    @GET("comment")
    fun getComment(
        @Query("idPost") idPost: Int
    ): Call<CommentResponse>

    //Upload Comment
    @Multipart
    @POST("comment")
    fun uploadComment(
        @Part("idPost") idPost: RequestBody,
        @Part("body") body: RequestBody,
        @Part("createdBy") createdBy: RequestBody,
        @Part("dateCreated") dateCreated: RequestBody
    ): Call<FileUploadResponse>



}