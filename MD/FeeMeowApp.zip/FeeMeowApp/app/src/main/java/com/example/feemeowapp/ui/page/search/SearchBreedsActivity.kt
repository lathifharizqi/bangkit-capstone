package com.example.feemeowapp.ui.page.search

import android.app.SearchManager
import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.appcompat.widget.SearchView
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.feemeowapp.databinding.ActivitySearchBreedsBinding
import com.example.feemeowapp.ui.adapter.BreedsCatAdapter
import com.example.feemeowapp.ui.api.apiConfig

import com.example.feemeowapp.ui.model.BreedsCat
import com.example.feemeowapp.ui.response.GetCommentResultItem
import com.example.feemeowapp.ui.response.RasSearchResponse
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class SearchBreedsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySearchBreedsBinding
    private var listBreeds = ArrayList<BreedsCat>()
    private lateinit var breedsCatAdapter: BreedsCatAdapter

    companion object {
        private const val TAG = "SearchBreedsActivity"
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySearchBreedsBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)
        setTitle("Breeds Cat Search")

        val layoutManager = LinearLayoutManager(this)
        binding.tvUser.layoutManager = layoutManager
        val itemDecoration = DividerItemDecoration(this, layoutManager.orientation)
        binding.tvUser.addItemDecoration(itemDecoration)

        val searchManager = getSystemService(Context.SEARCH_SERVICE) as SearchManager

        binding.tvSearch.setSearchableInfo(searchManager.getSearchableInfo(componentName))
        binding.tvSearch.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String): Boolean {
                return if(query.isEmpty())
                    true
                else {
                    val size = listBreeds.size
                    listBreeds.clear()
                    binding.tvUser.adapter?.notifyItemRangeRemoved(0, size)

                    findBreeds(query)
                    true
                }
            }
            override fun onQueryTextChange(newText: String): Boolean {
                return false
            }
        })
    }

    private fun findBreeds(name: String) {
        showLoading(true)
        val client = apiConfig.apiService.getSearch(name)
        client.enqueue(object : Callback<RasSearchResponse> {

            override fun onResponse(
                call: Call<RasSearchResponse>,
                response: Response<RasSearchResponse>

            ) {
                showLoading(false)
                if (response.isSuccessful) {
                    val responseBody = response.body()
                    if (responseBody != null) {
                        responseBody.getCommentResult.let{ setUserData(it) }
//                        AlertDialog.Builder(this@SearchBreedsActivity).apply {
////                            setTitle("Yeah!")
////                            setMessage("Yeay Your Breeds Cat Found Here")
////                            setPositiveButton("Next") { _, _ ->
////                                val intent = Intent(context, SearchBreedsActivity::class.java)
////                                intent.flags =
////                                    Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK
////                                startActivity(intent)
////                                finish()
////                            }
////                            create()
////                            show()
//                        }
                    }
                } else {
                    Log.e(TAG, "onFailure: ${response.message()}")
                    Toast.makeText(
                        this@SearchBreedsActivity,
                        "Breeds Not Found",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
            override fun onFailure(call: Call<RasSearchResponse>, t: Throwable) {
                showLoading(false)
                Log.e(TAG, "onFailure: ${t.message}")
                Toast.makeText(
                    this@SearchBreedsActivity,
                    "Search Failed",
                    Toast.LENGTH_SHORT
                ).show()
            }
        })
    }

    private fun setUserData(it: List<GetCommentResultItem>?) {
        if (it != null) {
            for (Ras in it) {
                val newRas = BreedsCat(Ras.name, Ras.image)
                listBreeds.add(newRas)
            }
        }
        breedsCatAdapter = BreedsCatAdapter(listBreeds, this@SearchBreedsActivity)
        binding.tvUser.adapter = breedsCatAdapter
        binding.tvUser.layoutManager = LinearLayoutManager(this)
        breedsCatAdapter.setOnItemClickCallback(object : BreedsCatAdapter.OnItemClickCallback {
            override fun onItemClicked(data: BreedsCat) {
                moveDetail(data)
            }
        })
    }

    private fun moveDetail(data: BreedsCat) {
        val username = ambilName(data)
        val intent = Intent(this@SearchBreedsActivity, DetailSearchActivity::class.java)
        intent.putExtra(DetailSearchActivity.username1, username)
        startActivity(intent)
    }

    private fun ambilName(data: BreedsCat): BreedsCat?  {
        var ambil: BreedsCat? = null

        for(ras in listBreeds) {
            if(ras.nama == data.nama)
                ambil = ras
        }
        return ambil
    }

    private fun showLoading(isLoading: Boolean) {
        if (isLoading) {
            binding.ProgresBar.visibility = View.VISIBLE
        } else {
            binding.ProgresBar.visibility = View.GONE
        }
    }


}