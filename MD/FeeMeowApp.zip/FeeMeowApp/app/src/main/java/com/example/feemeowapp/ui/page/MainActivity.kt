package com.example.feemeowapp.ui.page

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import com.example.feemeowapp.R
import com.example.feemeowapp.ui.page.fragment.*
import com.google.android.material.bottomnavigation.BottomNavigationView

class MainActivity : AppCompatActivity() {

    val fragmentHomeFragment: Fragment = HomeFragment()
    val fragmentHistoryFragment: Fragment = HistoryFragment()
    val fragmentScanFragment: Fragment = ScanFragment()
    val fragmentForumFragment: Fragment = ForumFragment()
    val fragmentProfileFragment: Fragment = ProfileFragment()
    val fm: FragmentManager = supportFragmentManager
    var active: Fragment = fragmentHomeFragment

    private lateinit var menu: Menu
    private lateinit var menuItem: MenuItem
    private lateinit var bottomNavigationView: BottomNavigationView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        actionBottomNav()
    }

    fun actionBottomNav() {

        fm.beginTransaction().add(R.id.container, fragmentHomeFragment).show(fragmentHomeFragment)
            .commit()
        fm.beginTransaction().add(R.id.container, fragmentHistoryFragment)
            .hide(fragmentHistoryFragment).commit()
        fm.beginTransaction().add(R.id.container, fragmentScanFragment).hide(fragmentScanFragment)
            .commit()
        fm.beginTransaction().add(R.id.container, fragmentForumFragment).hide(fragmentForumFragment)
            .commit()
        fm.beginTransaction().add(R.id.container, fragmentProfileFragment)
            .hide(fragmentProfileFragment).commit()

        bottomNavigationView = findViewById(R.id.nav_view)
        menu = bottomNavigationView.menu
        menuItem = menu.getItem(0)
        menuItem.isChecked = true

        bottomNavigationView.setOnNavigationItemReselectedListener { item ->

            when (item.itemId) {
                R.id.miHome -> {
                    callFragment(0, fragmentHomeFragment)
                }
                R.id.miHistory -> {
                    callFragment(1, fragmentHistoryFragment)
                }
                R.id.miScan -> {
                    callFragment(2, fragmentScanFragment)
                }
                R.id.miForum -> {
                    callFragment(3, fragmentForumFragment)
                }
                R.id.miProfile -> {
                    callFragment(4, fragmentProfileFragment)
                }
            }
            false
        }
    }

    fun callFragment(int: Int, fragment: Fragment) {
        Log.d("response", "profile")
        menuItem = menu.getItem(int)
        menuItem.isChecked = true
        fm.beginTransaction().hide(active).show(fragment).commit()
        active = fragment
    }
}



//        val navView: BottomNavigationView = findViewById(R.id.nav_view)

//        val navController = findNavController(R.id.nav_host_fragment_activity_main2)
//        val appBarConfiguration = AppBarConfiguration.Builder(
//            R.id.nav_dashboard, R.id.nav_history, R.id.nav_camera, R.id.nav_forum,
//            R.id.nav_profile
//        ).build()
//        setupActionBarWithNavController(navController,appBarConfiguration)
//        navView.setupWithNavController(navController)

//
//        binding.navView.background = null
//        binding.navView.menu.getItem(2).isEnabled = false
