package com.example.feemeowapp.ui.adapter

import android.view.LayoutInflater

import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.feemeowapp.databinding.ItemBreed2Binding
import com.example.feemeowapp.ui.model.BreedsCat
import com.example.feemeowapp.ui.page.fragment.HomeFragment
import com.example.feemeowapp.ui.page.search.SearchBreedsActivity


class BreedsCatAdapter(
    private val listRas: ArrayList<BreedsCat>, homeFragment: SearchBreedsActivity
): RecyclerView.Adapter<BreedsCatAdapter.ListViewHolder>() {
    private lateinit var onItemClickCallback: OnItemClickCallback

    fun setOnItemClickCallback(onItemClickCallback: OnItemClickCallback) {
        this.onItemClickCallback = onItemClickCallback
    }

    override fun onCreateViewHolder(viewGroup: ViewGroup, i: Int): ListViewHolder {
        val binding = ItemBreed2Binding.inflate(LayoutInflater.from(viewGroup.context), viewGroup, false)
        return ListViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ListViewHolder, position: Int) {
        val (nama, avatar) = listRas[position]
        holder.binding.tvItemName.text = nama

        Glide.with(holder.itemView.context)
            .load(avatar) // URL Gambar
            .circleCrop() // Mengubah image menjadi lingkaran
            .into(holder.binding.imgItemPhoto) // imageView mana yang akan diterapkan

        holder.binding.imgItemPhoto.setOnClickListener { onItemClickCallback.onItemClicked(listRas[holder.adapterPosition])
        }
    }

    override fun getItemCount(): Int = listRas.size
    class ListViewHolder(var binding: ItemBreed2Binding) : RecyclerView.ViewHolder(binding.root)

    interface OnItemClickCallback {
        fun onItemClicked(data: BreedsCat)
    }
}
