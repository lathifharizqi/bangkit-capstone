package com.example.feemeowapp.ui.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions
import com.example.feemeowapp.databinding.ItemBreedBinding
import com.example.feemeowapp.ui.page.fragment.HomeFragment
import com.example.feemeowapp.ui.response.RasDasboardResponse

class BreedsDashboardAdapter(
    private val datas: ArrayList<RasDasboardResponse.GetSearchResultItem>,
    val ctx: HomeFragment
) :
    RecyclerView.Adapter<BreedsDashboardAdapter.MyViewHolder>() {

    private var onItemClickCallback: OnItemClickCallback? = null

    fun setOnItemClickCallback(onItemClickCallback: OnItemClickCallback) {
        this.onItemClickCallback = onItemClickCallback
    }

    inner class MyViewHolder(val binding: ItemBreedBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(ras: RasDasboardResponse.GetSearchResultItem) {
            binding.root.setOnClickListener {
                onItemClickCallback?.onItemClicked(ras)
            }
            binding.apply {
                Glide.with(itemView)
                    .load(ras.image)
                    .transition(DrawableTransitionOptions.withCrossFade())
                    .into(imgBreeds1)
                tvNamaBreeds.text = ras.name
                tvDeksBreeds.text = ras.description
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val itemView = ItemBreedBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return MyViewHolder((itemView))
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        holder.bind(datas[position])
    }

    override fun getItemCount(): Int = datas.size

    fun setData(data: ArrayList<RasDasboardResponse.GetSearchResultItem>) {
        datas.clear()
        datas.addAll(data)
        notifyDataSetChanged()
    }

    interface OnItemClickCallback {
        fun onItemClicked(data: RasDasboardResponse.GetSearchResultItem)
    }
}