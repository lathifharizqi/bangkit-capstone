package com.example.feemeowapp.ui.response

import com.google.gson.annotations.SerializedName

data class RasSearchResponse(

	@field:SerializedName("error")
	val error: Boolean,

	@field:SerializedName("message")
	val message: String,

	@field:SerializedName("getCommentResult")
	val getCommentResult: List<GetCommentResultItem>? = null,
)

data class GetCommentResultItem(

	@field:SerializedName("name")
	val name: String,

	@field:SerializedName("image")
	val image: String,

	@field:SerializedName("description")
	val description: String,

	@field:SerializedName("idBreed")
	val idBreed: Int,


)

