package com.example.feemeowapp.ui.forum

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions
import com.example.feemeowapp.databinding.ItemRowBinding

class RVAdapter(
    private val datas: ArrayList<ResponseModel.GetForumResultItem>,
    val ctx: Context
) :
    RecyclerView.Adapter<RVAdapter.MyViewHolder>() {

    private var onItemClickCallback: OnItemClickCallback? = null

    fun setOnItemClickCallback(onItemClickCallback: OnItemClickCallback) {
        this.onItemClickCallback = onItemClickCallback
    }

    inner class MyViewHolder(val binding: ItemRowBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(user: ResponseModel.GetForumResultItem) {
            binding.root.setOnClickListener {
                onItemClickCallback?.onItemClicked(user)
            }
            binding.apply {
                Glide.with(itemView)
                    .load(user.imageBase64)
                    .transition(DrawableTransitionOptions.withCrossFade())
                    .into(ivMainImage)
                tvFullname.text = user.namaLengkap
                tvDate.text = user.dateCreated
                tvMainTitle.text = user.title
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val itemView = ItemRowBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return MyViewHolder((itemView))
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        holder.bind(datas[position])

    }

    override fun getItemCount(): Int = datas.size

    fun setData(data: ArrayList<ResponseModel.GetForumResultItem>) {
        datas.clear()
        datas.addAll(data)
        notifyDataSetChanged()
    }

    interface OnItemClickCallback {
        fun onItemClicked(data: ResponseModel.GetForumResultItem)
    }
}