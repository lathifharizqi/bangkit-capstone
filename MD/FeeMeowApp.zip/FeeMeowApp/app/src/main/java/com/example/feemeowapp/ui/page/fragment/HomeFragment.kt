package com.example.feemeowapp.ui.page.fragment

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import androidx.fragment.app.Fragment
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.feemeowapp.R
import com.example.feemeowapp.databinding.FragmentHomeBinding
import com.example.feemeowapp.ui.adapter.BreedsDashboardAdapter
import com.example.feemeowapp.ui.api.apiConfig
import com.example.feemeowapp.ui.page.detail.RasDetailActivity
import com.example.feemeowapp.ui.page.search.SearchBreedsActivity
import com.example.feemeowapp.ui.response.RasDasboardResponse
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class HomeFragment : Fragment(R.layout.fragment_home) {

    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!
    private lateinit var adapter:BreedsDashboardAdapter

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        val view = binding.root
        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        adapter = BreedsDashboardAdapter(arrayListOf(), this@HomeFragment)
        binding.rvBreeds.layoutManager = LinearLayoutManager(requireActivity())
        binding.rvBreeds.setHasFixedSize(true)
        binding.rvBreeds.adapter = adapter

        getRas()

        adapter.notifyDataSetChanged()

        adapter.setOnItemClickCallback(object : BreedsDashboardAdapter.OnItemClickCallback {
            override fun onItemClicked(data: RasDasboardResponse.GetSearchResultItem) {
                startActivity(
                    Intent(requireActivity(), RasDetailActivity::class.java)
                        .putExtra("intent_ras", data.name)
                        .putExtra("intent_image", data.image)
                        .putExtra("intent_description", data.description)
                )
            }
        })

        ButtonSearchAction()
        TextSearchAction()
    }


    fun getRas() {
        apiConfig.apiService.getRas().enqueue(object : Callback<RasDasboardResponse> {
            override fun onResponse(call: Call<RasDasboardResponse>, response: Response<RasDasboardResponse>) {
                if (response.isSuccessful) {
                    val data = response.body()
                    if (data != null) {
                        setData(data.getSearchResult)
                    }
                }
            }

            override fun onFailure(call: Call<RasDasboardResponse>, t: Throwable) {
                Log.d("Error Get", "" + t.stackTraceToString())
            }
        })
    }

    fun setData(data: ArrayList<RasDasboardResponse.GetSearchResultItem>) {
        adapter.setData(data)
    }

    private fun ButtonSearchAction(){
        binding.btnSearch.setOnClickListener{
            val i = Intent(requireActivity(), SearchBreedsActivity::class.java)
            startActivity(i)
        }
    }
    private fun TextSearchAction(){
        binding.txtSearch.setOnClickListener{
            val i = Intent(requireActivity(), SearchBreedsActivity::class.java)
            startActivity(i)
        }
    }

}


