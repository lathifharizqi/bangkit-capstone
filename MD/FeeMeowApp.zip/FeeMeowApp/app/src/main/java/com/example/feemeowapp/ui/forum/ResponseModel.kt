package com.example.feemeowapp.ui.forum

import com.google.gson.annotations.SerializedName

data class  ResponseModel(

    @field:SerializedName("getForumResult")
    val getForumResult: ArrayList<GetForumResultItem>,

    @field:SerializedName("error")
    val error: Boolean? = null,

    @field:SerializedName("message")
    val message: String? = null
) {

    data class GetForumResultItem(

        @field:SerializedName("imageLink")
        val imageBase64: String? = null,

        @field:SerializedName("file")
        val fileImage: String? = null,

        @field:SerializedName("dateCreated")
        val dateCreated: String? = null,

        @field:SerializedName("createdBy")
        val createdBy: String? = null,

        @field:SerializedName("nama_lengkap")
        val namaLengkap: String? = null,

        @field:SerializedName("body")
        val body: String? = null,

        @field:SerializedName("title")
        val title: String? = null,

        @field:SerializedName("breed")
        val breed: String? = null,

        @field:SerializedName("idPost")
        val idPost: Int
    )
}
