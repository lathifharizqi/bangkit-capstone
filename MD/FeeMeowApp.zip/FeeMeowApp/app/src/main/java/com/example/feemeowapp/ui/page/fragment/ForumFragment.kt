package com.example.feemeowapp.ui.page.fragment

import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.Animation
import android.view.animation.AnimationUtils

import androidx.recyclerview.widget.LinearLayoutManager
import com.example.feemeowapp.R
import com.example.feemeowapp.databinding.FragmentForumBinding
import com.example.feemeowapp.ui.api.apiConfig
import com.example.feemeowapp.ui.detilforum.DetailForumActivity

import com.example.feemeowapp.ui.forum.RVAdapter
import com.example.feemeowapp.ui.forum.ResponseModel
import com.example.feemeowapp.ui.page.addforumwithimage.NewForumActivity
import com.example.feemeowapp.ui.page.addforumnoimage.AddForumNoImageActivity

import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


class ForumFragment : Fragment() {

    private lateinit var adapter: RVAdapter

    private var _binding: FragmentForumBinding? = null

    private val binding get() = _binding!!

    private val rorateOpen: Animation by lazy {
        AnimationUtils.loadAnimation(
            requireActivity(),
            R.anim.rotate_open_anim
        )
    }
    private val rorateClose: Animation by lazy {
        AnimationUtils.loadAnimation(
            requireActivity(),
            R.anim.rotate_close_anim
        )
    }
    private val fromBottom: Animation by lazy {
        AnimationUtils.loadAnimation(
            requireActivity(),
            R.anim.from_bottom_anim
        )
    }
    private val toBottom: Animation by lazy {
        AnimationUtils.loadAnimation(
            requireActivity(),
            R.anim.to_bottom_anim
        )
    }

    private var clicked = false


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {

        }
    }


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment

        _binding = FragmentForumBinding.inflate(inflater, container, false)
        val view = binding.root
        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        adapter = RVAdapter(arrayListOf(), requireActivity())
        binding.rvMain.layoutManager = LinearLayoutManager(requireActivity())
        binding.rvMain.setHasFixedSize(true)
        binding.rvMain.adapter = adapter
        getStudents()

//        (activity as AppCompatActivity).supportActionBar?.title = "Forum"


        adapter.notifyDataSetChanged()

        binding.fabAdd.setOnClickListener {
            onAddButtonClicked()
        }

        binding.fabImage.setOnClickListener {
            val intent = Intent(requireActivity(), NewForumActivity::class.java)
            startActivity(intent)
        }

        binding.fabText.setOnClickListener {
            val intent = Intent(requireContext(), AddForumNoImageActivity::class.java)
            startActivity(intent)
        }

        adapter.setOnItemClickCallback(object : RVAdapter.OnItemClickCallback {
            override fun onItemClicked(data: ResponseModel.GetForumResultItem) {
                startActivity(
                    Intent(requireContext(), DetailForumActivity::class.java)
                        .putExtra("intent_fullname", data.namaLengkap)
                        .putExtra("intent_date", data.dateCreated)
                        .putExtra("intent_description", data.body)
                        .putExtra("intent_title", data.title)
                        .putExtra("intent_image", data.imageBase64)
                        .putExtra(DetailForumActivity.EXTRA_ID, data.idPost)
                )
            }

        })

//        val btnImage: ImageButton = view.findViewById(R.id.fab_image)
//        btnImage.setOnClickListener(this)
    }

    fun getStudents() {
        val retIn = apiConfig.apiService
        retIn.getForum().enqueue(object : Callback<ResponseModel> {
            override fun onResponse(call: Call<ResponseModel>, response: Response<ResponseModel>) {
                if (response.isSuccessful) {
                    val data = response.body()
                    if (data != null) {
                        setData(data.getForumResult)
                    }
                }
            }

            override fun onFailure(call: Call<ResponseModel>, t: Throwable) {
                Log.d("Error Get", "" + t.stackTraceToString())
            }
        })
    }

    fun setData(data: ArrayList<ResponseModel.GetForumResultItem>) {
        adapter.setData(data)
    }

    private fun onAddButtonClicked() {
        setVisibility(clicked)
        setAnimation(clicked)
        setClickable(clicked)
        clicked = !clicked
    }

    private fun setAnimation(clicked: Boolean) {
        if (!clicked) {
            binding.fabText.startAnimation(fromBottom)
            binding.fabImage.startAnimation(fromBottom)
            binding.fabAdd.startAnimation(rorateOpen)
        } else {
            binding.fabText.startAnimation(toBottom)
            binding.fabImage.startAnimation(toBottom)
            binding.fabAdd.startAnimation(rorateClose)
        }
    }

    private fun setVisibility(clicked: Boolean) {
        if (!clicked) {
            binding.fabText.visibility = View.VISIBLE
            binding.fabImage.visibility = View.VISIBLE
        } else {
            binding.fabText.visibility = View.INVISIBLE
            binding.fabImage.visibility = View.INVISIBLE
        }
    }

    private fun setClickable(clicked: Boolean) {
        if (!clicked) {
            binding.fabText.isClickable = true
            binding.fabImage.isClickable = true
        } else {
            binding.fabText.isClickable = false
            binding.fabImage.isClickable = false
        }
    }

}