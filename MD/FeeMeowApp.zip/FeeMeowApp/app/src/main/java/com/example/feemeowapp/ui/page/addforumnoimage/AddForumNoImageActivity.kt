package com.example.feemeowapp.ui.page.addforumnoimage

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import com.example.feemeowapp.databinding.ActivityAddForumNoImageBinding
import com.example.feemeowapp.ui.api.apiConfig

import com.example.feemeowapp.ui.helper.Constant
import com.example.feemeowapp.ui.helper.PreferencesHelper
import com.example.feemeowapp.ui.page.MainActivity

import com.example.feemeowapp.ui.page.fragment.ForumFragment
import com.example.feemeowapp.ui.response.FileUploadResponse
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class AddForumNoImageActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAddForumNoImageBinding
    lateinit var sharedPref: PreferencesHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAddForumNoImageBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.uploadButton.setOnClickListener { uploadText() }

        sharedPref = PreferencesHelper(this)

    }

    private fun uploadText() {
        val sfUsername = sharedPref.getString(Constant.PREF_USERNAME)

        val title = binding.etTitle.text.toString().toRequestBody("text/plain".toMediaType())
        val body =
            binding.etDescription.text.toString().toRequestBody("text/plain".toMediaType())
        val createdBy = sfUsername?.toRequestBody("text/plain".toMediaType())
        val dateCreated = "22-02-02".toRequestBody("text/plain".toMediaType())


        val service =
            createdBy?.let { apiConfig.apiService.uploadText(title, body, it, dateCreated) }

        if (service != null) {
            service.enqueue(object : Callback<FileUploadResponse> {
                override fun onResponse(
                    call: Call<FileUploadResponse>,
                    response: Response<FileUploadResponse>
                ) {
                    if (response.isSuccessful) {
                        val responseBody = response.body()
                        if (responseBody != null && !responseBody.error) {
                            AlertDialog.Builder(this@AddForumNoImageActivity).apply {
                                setTitle("Yeah!")
                                setMessage("Succsess add new forum!")
                                setPositiveButton("Next") { _, _ ->
                                    val intent = Intent(this@AddForumNoImageActivity, MainActivity::class.java)
                                    intent.flags =
                                        Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK
                                    startActivity(intent)
                                    finish()
                                }
                                create()
                                show()
                            }
                            Toast.makeText(
                                this@AddForumNoImageActivity,
                                responseBody.message,
                                Toast.LENGTH_SHORT
                            ).show()
                            intentForum()
                        }
                    } else {
                        Toast.makeText(
                            this@AddForumNoImageActivity,
                            response.message(),
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }

                override fun onFailure(call: Call<FileUploadResponse>, t: Throwable) {
                    Toast.makeText(
                        this@AddForumNoImageActivity,
                        "Gagal memposting ke forum",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            })
        }
    }

    private fun intentForum() {
        val intent = Intent(this, ForumFragment::class.java)
        startActivity(intent)
    }
}