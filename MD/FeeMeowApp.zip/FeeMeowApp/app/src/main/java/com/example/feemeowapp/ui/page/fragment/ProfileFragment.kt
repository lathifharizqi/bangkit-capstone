package com.example.feemeowapp.ui.page.fragment

import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.example.feemeowapp.databinding.FragmentProfileBinding
import com.example.feemeowapp.ui.helper.Constant
import com.example.feemeowapp.ui.helper.PreferencesHelper
import com.example.feemeowapp.ui.page.welcome.WelcomeActivity

class ProfileFragment : Fragment() {

    private var _binding: FragmentProfileBinding? = null
    private val binding get() = _binding!!

    lateinit var sharedPref: PreferencesHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {

        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        _binding = FragmentProfileBinding.inflate(inflater, container, false)
        val view = binding.root
        return view    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        sharedPref = PreferencesHelper(requireActivity())
        binding.LogOutButton.setOnClickListener {
            sharedPref.clear()
            startActivity(Intent(requireActivity(),WelcomeActivity::class.java))
            sharedPref.put(Constant.PREF_IS_LOGIN, false)
        }
    }
}