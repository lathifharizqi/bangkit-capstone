package com.example.feemeowapp.ui.page.detail

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import com.bumptech.glide.Glide
import com.example.feemeowapp.databinding.ActivityRasDetailBinding
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class RasDetailActivity : AppCompatActivity() {

    private lateinit var binding: ActivityRasDetailBinding
//    private lateinit var adapter: DetailRasAdapter


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRasDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.hide()

        binding.txtNamaDetail .text = intent.getStringExtra("intent_title")
        binding.txtDeskDetail .text = intent.getStringExtra("intent_deskripsi")

        Glide.with(this)
            .load(intent.getStringExtra("intent_image"))
            .into(binding.imgGambarDetail)

//        adapter = CommentAdapter(arrayListOf(), this@DetailForumActivity)
//        binding.  .layoutManager = LinearLayoutManager(this)
//        binding.rvComment.setHasFixedSize(true)
//        binding.rvComment.adapter = adapter
//        getStudents()
//        uploadComment()
    }

//    private fun uploadComment() {
//
//        binding.btnSubmit.setOnClickListener {
//            val dateCreated = "22-02-02"
//            val createdBy = "iik1412"
//            val body = binding.edReview.text.toString()
//            val idPost = 3
//
//            val service = RClient.rService.uploadComment(
//                AddNewCommentRequest(
//                    dateCreated,
//                    createdBy,
//                    body,
//                    idPost
//                )
//            )
//
//            service.enqueue(object : Callback<AddNewCommentResponse> {
//                override fun onResponse(
//                    call: Call<AddNewCommentResponse>,
//                    response: Response<AddNewCommentResponse>
//                ) {
//                    if (response.isSuccessful) {
//                        val responseBody = response.body()
//                        if (responseBody != null) {
//                            Toast.makeText(
//                                this@DetailForumActivity,
////                                responseBody.message,
//                                "Berhasil",
//                                Toast.LENGTH_SHORT
//                            ).show()
//                        }
//                    } else {
//                        Toast.makeText(
//                            this@DetailForumActivity,
//                            response.message(),
//                            Toast.LENGTH_SHORT
//                        ).show()
//                    }
//                }
//
//                override fun onFailure(call: Call<AddNewCommentResponse>, t: Throwable) {
//                    Toast.makeText(
//                        this@DetailForumActivity,
//                        t.message,
//                        Toast.LENGTH_SHORT
//                    ).show()
//                    Log.d("Error Get", "" + t.message)
//                }
//            })
//        }
//    }
//
//
//    fun setData(data: ArrayList<CommentResponse.GetCommentResultItem>) {
//        adapter.setData(data)
//    }
//
//    fun getStudents() {
//        RClient.rService.getComment(3).enqueue(object : Callback<CommentResponse> {
//            override fun onResponse(
//                call: Call<CommentResponse>,
//                response: Response<CommentResponse>
//            ) {
//                if (response.isSuccessful) {
//                    val data = response.body()
//                    if (data != null) {
//                        setData(data.getCommentResult)
//                    }
//                }
//            }
//
//            override fun onFailure(call: Call<CommentResponse>, t: Throwable) {
//                Log.d("Error Get", "" + t.stackTraceToString())
//            }
//        })
//    }
}

